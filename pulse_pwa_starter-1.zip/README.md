# Pulse PWA starter

This package is prepared to be hosted as a Progressive Web App (PWA).

## How to publish
Upload the contents of this folder to the root of a public GitHub repository and enable GitHub Pages from Settings → Pages → Deploy from a branch → main → /(root).

After the site is live on its HTTPS GitHub Pages address:
1. Open the address in Chrome on Android.
2. Tap the three-dot menu.
3. Choose "Install app" or "Add to Home screen" if shown.

## Important
This is still a front-end demo. It has no real online accounts, shared posts, real messaging, or cloud database. Current interactions are local to the browser/device.
